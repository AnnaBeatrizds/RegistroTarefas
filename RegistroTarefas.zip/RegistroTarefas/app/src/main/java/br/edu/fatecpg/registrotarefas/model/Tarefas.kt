package br.edu.fatecpg.registrotarefas.model

data class Tarefas(
    val titulo:String = "",
    val descricao:String = "",
    var feito:Boolean = false
)
