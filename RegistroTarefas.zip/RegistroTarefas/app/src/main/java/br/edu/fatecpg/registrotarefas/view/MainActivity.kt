package br.edu.fatecpg.registrotarefas.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.registrotarefas.R
import br.edu.fatecpg.registrotarefas.adapter.TarefasAdapter
import br.edu.fatecpg.registrotarefas.dao.TarefasDao
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TarefasAdapter
    private lateinit var dao: TarefasDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main   )

        dao = TarefasDao()
        recyclerView = findViewById(R.id.rv_lista)

        val tarefas = dao.obterTarefas().toMutableList()
        adapter = TarefasAdapter(tarefas)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val fabAdicionar = findViewById<FloatingActionButton>(R.id.fab_adicionar)
        fabAdicionar.setOnClickListener(){
            val intent = Intent(this, AdicionarActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        updateData()
    }

    private fun updateData() {
        val tarefasAtualizadas = dao.obterTarefas().toMutableList()
        adapter.atualizarLista(tarefasAtualizadas)
        Log.i("tarefas", "$tarefasAtualizadas")
    }
}