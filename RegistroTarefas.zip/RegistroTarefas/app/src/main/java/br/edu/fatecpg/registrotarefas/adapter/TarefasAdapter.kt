package br.edu.fatecpg.registrotarefas.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.registrotarefas.R
import br.edu.fatecpg.registrotarefas.model.Tarefas

class TarefasAdapter (private var tarefas: MutableList<Tarefas>) : RecyclerView.Adapter<TarefasAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tituloTarefa: TextView = itemView.findViewById(R.id.txv_titulo)
        val descricaoTarefa: TextView = itemView.findViewById(R.id.txv_descricao)
        val botaoConcluir: Button = itemView.findViewById(R.id.btn_concluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_tarefa, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return tarefas.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val task = tarefas[position]

        holder.tituloTarefa.text = task.titulo
        holder.descricaoTarefa.text = task.descricao

        holder.botaoConcluir.setOnClickListener {
            // Muda o valor de isChecked para true
            task.feito = true

            // Remove a tarefa da lista e notifica a mudança
            tarefas.removeAt(position)
            notifyItemRemoved(position)

            // Atualiza a lista (caso precise)
            atualizarLista(tarefas)
        }
    }

    // Método para atualizar a lista de tarefas
    fun atualizarLista(novasTarefas: MutableList<Tarefas>) {
        tarefas = novasTarefas
        notifyDataSetChanged()
    }
}
