package br.edu.fatecpg.registrotarefas.dao

import br.edu.fatecpg.registrotarefas.model.Tarefas

class TarefasDao {
    companion object {
        private val Tarefas: MutableList<Tarefas> = mutableListOf()
    }

    fun adicionarTarefa(tarefa: Tarefas) {
        Tarefas.add(tarefa)
    }

    fun obterTarefas(): List<Tarefas> {
        return Tarefas.filter { !it.feito }
    }
}